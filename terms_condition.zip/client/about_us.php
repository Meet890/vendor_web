<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title> An About Us Page | CoderGirl </title>
  <!---Custom Css File!--->
  
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<?php
  include("header.php");

  ?>
  <section class="about-us">
    <div class="about">
      <img src="../img/about.jpg" class="pic">
      <div class="text">
        <h2>About Us</h2>
        <!-- <h5>Front-end Developer & <span>Designer</span></h5> -->
          <p>The client can easilly find his choise vendors.</p>
          <p>We are provide vendor to customer, but we have never lost sight of our core values. We believe in collaborat innovation, and customer satisfaction. We are always looking for new ways to improve our vendor.</p>
          <p>vendor management system is online platform which provides all kind of  vandor like photographer , decoraters,catering and many more vendors for you events. in vendor management system vendors can register in website
			    and provide their details on it which we are showing on our website.any person can find vanders from this system according their requirements</p>						  
          <p><a href="privacy_policy.php" class="a3">Privacy Policy</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="terms_condition.php" class="a3">Terms & Conditions </a></p>

       <!-- <div class="data">
        <a href="#" class="hire">Hire Me</a>
        </div> -->
      </div>
    </div>
  </section>
 
</body>
</html>