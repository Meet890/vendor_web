<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="vendor_api_style.css">
    <title>profile</title>
</head>
<body>
<!-- <?php 
    // include("header.php");
?> -->
    <div class="main">
        <div class="profile"><img src="../img/img1.jpeg" alt=""></div>
        <div class="detail">
            <div class="post">
              <h2>14</h2>
              <p>post</p>
            </div>
            <div class="followers">
                <h2>989</h2>
                <p>folloewrs</p>
            </div>
            <div class="following">
                <h2>989</h2>
                <p>folloewing</p>
            </div>
        </div>
        <br>
        <div class="info">
            <div class="name">
                <h3>vendor name</h3>
            </div>
            <div class="services">
                <h3>services</h3>
            </div>
            <div class="work">
                <h3>city</h3>
                
            </div>
            
            <div class="button">
                <br>
                <!-- <div class="edit"><button>Edit profile</button></div> -->
                <h2 class="center">About us</h2><br>
                <h5 class="">Trees are not a monophyletic taxonomic group but consist of a wide variety of plant species that have 
                    independently evolved a trunk and branches as a way to tower above other plants to compete for sunlight.
                     The majority of tree species are angiosperms or hardwoods; of the rest,
                     many are gymnosperms or softwoods. Trees tend to be long-lived, some reaching several thousand years old. </h5>
                <br>
                <!-- <div class="links">
                    <button>Promotion</button>
                    <button>Insights</button>
                    <button>Contact</button>
                </div> -->
            </div><br>
           
            <div class="gellery">
                <h2  class="center">Gellery</h2>
            </div>
            
        </div>
        <!-- <div class="row">
        <div class="col-md-4  col-sm-6 ">
            <img src="../img/cake.jpg" alt="" class="g_img">
        </div>    
        <div class="col-md-4  col-sm-6 ">
            <img src="../img/cake.jpg" alt="" class="g_img">
        </div>
        <div class="col-md-4  col-sm-6 ">
            <img src="../img/cake.jpg" alt="" class="g_img">
        </div>
        </div> -->
    </div>
</body>
</html>